import dza,{a,b,c} from './module2.mjs'
console.log(dza);
console.log(a);
console.log(b);
console.log(c);
