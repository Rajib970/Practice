const a ="Harry";
const b = "Rohan";
const c = "Akash";
const d = "Priyanka";

export default d;
export {a};
export {b};
export {c};
// export {d};
